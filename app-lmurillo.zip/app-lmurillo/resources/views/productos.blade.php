
<h1>Lista de Productos</h1>



@foreach ($prod as $item)
    <h2>{{ $item->nombre}}</h2>
    
@endforeach
